package com.example.pizzadelivery;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class MenuController {
    public static double price = 0;
    public void onClickButtonMenu550(ActionEvent actionEvent) {
        price+=550;
    }

    public void onClickButtonMenu320(ActionEvent actionEvent) {
        price+=320;
    }

    public void onClickButtonMenu89(ActionEvent actionEvent) {
        price+=89;
    }

    public void onClickButtonMenu79(ActionEvent actionEvent) {
        price+=79;
    }

    public void onClickButtonMenu110(ActionEvent actionEvent) {
        price+=110;
    }

    public void onButtonClickCart(ActionEvent actionEvent) throws IOException {
        Stage cartStage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("shopping-cart.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 700, 500);
        cartStage.setTitle("Menu");
        cartStage.setScene(scene);
        cartStage.show();
    }
}
