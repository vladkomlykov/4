package com.example.pizzadelivery;

import data.User;
import data.Users;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {
    @FXML
    public TextField loginField;
    @FXML
    public PasswordField passwordField;
    @FXML


    public void onLoginButtonClick(ActionEvent actionEvent) throws IOException {
        if (checkData()) {
            showMenu();
        }
        System.out.println("Неверные данные!");
    }

    private void showMenu() throws IOException {
        Stage menuStage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 700, 500);
        menuStage.setTitle("Menu");
        menuStage.setScene(scene);
        menuStage.show();
    }

    private boolean checkData(){
        Users usersList = new Users();
        for (User user : usersList.users){
            if (user.getNumber().equals(loginField.getText()) && user.getPassword().equals(passwordField.getText())){
                return true;
            }
        }
        return false;
    }
}