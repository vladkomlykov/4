package com.example.pizzadelivery;

import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class CartController implements Initializable {
    public Label priceLable;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        priceLable.setText(String.valueOf(MenuController.price));
    }
}
