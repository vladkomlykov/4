package data;

import java.util.ArrayList;
import java.util.List;

public class Users {
    public List<User> users = new ArrayList<>();
    {
        User admin = new User("admin", "0000");
        User user1 = new User("9992428985", "0112");

        users.add(admin);
        users.add(user1);
    }
}
